from Hola.Hola import Saludo
from Adios.Adios import *

Saludo()
Adios()