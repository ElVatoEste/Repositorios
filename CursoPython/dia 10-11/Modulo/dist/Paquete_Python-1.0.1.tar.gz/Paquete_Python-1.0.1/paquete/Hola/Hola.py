def Saludo():
    print('-------------------')
    print('Hola Gente')
    print('-------------------')
