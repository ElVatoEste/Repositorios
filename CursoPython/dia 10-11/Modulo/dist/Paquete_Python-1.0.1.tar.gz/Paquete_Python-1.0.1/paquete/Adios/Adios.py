def Adios():
    print('-------------------')
    print('Adios Gente')
    print('-------------------')