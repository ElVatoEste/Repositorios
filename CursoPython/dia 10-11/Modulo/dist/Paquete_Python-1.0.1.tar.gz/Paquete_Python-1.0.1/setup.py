from setuptools import setup
setup(
    name= 'Paquete_Python',
    version= '1.0.1',
    description= ('Es un paquete practica'),
    author= 'Vato_Dev',
    author_email= 'bigmalv@gmail.com',
    packages=['paquete', 'paquete.Hola', 'paquete.Adios'],
    scripts=[]
)